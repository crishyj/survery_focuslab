<?php if(auth()->check() && !in_array(request()->route()->getName(), ['welcome'])): ?>
    <?php echo $__env->make('layouts.navbars.navs.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
    
<?php if(!auth()->check() || in_array(request()->route()->getName(), ['welcome'])): ?>
    <?php echo $__env->make('layouts.navbars.navs.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?><?php /**PATH E:\WEB\2021-05\10\survey\resources\views/layouts/navbars/navbar.blade.php ENDPATH**/ ?>