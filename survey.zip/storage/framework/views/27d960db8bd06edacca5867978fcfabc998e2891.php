

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <?php echo e(__('View Survey Detail')); ?>

                </div>

                <div class="card-body">
                    <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="row">    
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Name')); ?></label>                        
                            <div class="col-md-6">
                                <div class="detail_value">
                                    <h3>
                                        <?php echo e($option->name); ?>                          
                                    </h3>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Survey Header')); ?></label>

                            <div class="col-md-6">
                                <div class="detail_value">
                                    <h3>
                                        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($item->id == $option->project_id): ?>
                                                <?php echo e($item->heading); ?>

                                            <?php endif; ?>                                            
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </h3>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Client')); ?></label>

                            <div class="col-md-6">
                                <div class="detail_value">
                                    <h3>
                                        <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($item->id == $option->client_id): ?>
                                                <?php echo e($item->name); ?>

                                            <?php endif; ?>                                            
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </h3>
                                </div>
                            </div>
                        </div>


                        <div class="row">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Project')); ?></label>

                            <div class="col-md-6">
                                <div class="detail_value">
                                    <h3>
                                        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($item->id == $option->project_id): ?>
                                                <?php echo e($item->name); ?>

                                            <?php endif; ?>                                            
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </h3>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Description')); ?></label>

                            <div class="col-md-6">
                                <div class="detail_value">
                                    <h3>
                                        <?php echo e($option->description); ?>                                       
                                    </h3>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Start Date')); ?></label>

                            <div class="col-md-6">
                                <div class="detail_value">
                                    <h3>
                                        <?php echo e($option->start); ?>                                       
                                    </h3>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('End Date')); ?></label>

                            <div class="col-md-6">
                                <div class="detail_value">
                                    <h3>
                                        <?php echo e($option->end); ?>                                       
                                    </h3>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Code')); ?></label>

                            <div class="col-md-6">
                                <div class="detail_value">
                                    <h3>
                                        <?php echo e($option->code); ?>                                       
                                    </h3>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Link')); ?></label>

                            <div class="col-md-6">
                                <div class="detail_value">
                                    <h3>
                                        <?php echo e($option->surveylink); ?>                                       
                                    </h3>
                                </div>
                            </div>
                        </div>

                        <div class="row">    
                            <div class="col-md-4 text-md-right py-2">Culture Dim</div>                          
                            <div class="col-md-6">
                                <div class="detail_value">
                                    <h3>
                                        <?php if($option->culturedim_check == 'on'): ?>
                                            <?php echo e('On'); ?>                                      
                                        <?php else: ?>
                                            <?php echo e('Off'); ?>                                        
                                        <?php endif; ?>
                                    </h3>
                                </div>
                            </div>
                        </div>

                        <div class="row">    
                            <div class="col-md-4 text-md-right py-2">Critical Fact</div>                          
                            <div class="col-md-6">
                                <div class="detail_value">
                                    <h3>
                                        <?php if($option->criticalfact_check == 'on'): ?>
                                            <?php echo e('On'); ?>

                                        <?php else: ?>
                                            <?php echo e('Off'); ?>

                                        <?php endif; ?>
                                    </h3>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row">    
                            <div class="col-md-4 text-md-right py-2">Balance Card</div>                          
                            <div class="col-md-6">
                                <div class="detail_value">
                                    <h3>
                                        <?php if($option->balancecard_check == 'on'): ?>
                                            <?php echo e('On'); ?>

                                        <?php else: ?>
                                            <?php echo e('Off'); ?>

                                        <?php endif; ?>
                                    </h3>
                                </div>
                            </div>
                        </div>

                        <?php if($option->company_check == 'on'): ?>
                            <div class="form-group row">    
                                <label for="company" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Company')); ?></label>                         
                                <div class="col-md-6">
                                    <select name="company" id="company1" class="form-control">
                                        <?php $__currentLoopData = explode(',', $option->company); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                            <option><?php echo e($info); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                        <?php endif; ?>

                        
                        <?php if($option->city_check == 'on'): ?>
                            <div class="form-group row">    
                                <label for="city" class="col-md-4 col-form-label text-md-right"><?php echo e(__('City')); ?></label>                         
                                <div class="col-md-6">
                                    <select name="city" id="city1" class="form-control">
                                        <?php $__currentLoopData = explode(',', $option->city); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                            <option><?php echo e($info); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                        <?php endif; ?>

                        <?php if($option->companyarea_check == 'on'): ?>
                            <div class="form-group row">    
                                <label for="companyarea" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Company Area')); ?></label>                         
                                <div class="col-md-6">
                                    <select name="companyarea" id="companyarea1" class="form-control">
                                        <?php $__currentLoopData = explode(',', $option->companyarea); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                            <option><?php echo e($info); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                        <?php endif; ?>
                        
                        <?php if($option->companylevel_check == 'on'): ?>
                            <div class="form-group row">    
                                <label for="companylevel" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Company Level')); ?></label>                         
                                <div class="col-md-6">                                   
                                    <select name="companylevel" id="companylevel1" class="form-control">
                                        <?php $__currentLoopData = explode(',', $option->companylevel); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                            <option><?php echo e($info); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>                                  
                                </div>
                            </div>  
                        <?php endif; ?>
                                               
                        <?php if($option->companyjob_check == 'on'): ?>
                            <div class="form-group row">    
                                <label for="companylevel" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Company Job')); ?></label>                         
                                <div class="col-md-6">
                                    <select name="companyjob" id="companyjob1" class="form-control">
                                        <?php $__currentLoopData = explode(',', $option->companyjob); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                            <option><?php echo e($info); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                        <?php endif; ?>

                        <?php if($option->surveydate_check == 'on'): ?>
                            <div class="form-group row">    
                                <label for="companylevel" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Date')); ?></label>                         
                                <div class="col-md-6">
                                   <input type="date" name="survey_date" id="survey_date1" class="form-control survey_date">
                                </div>
                            </div>
                        <?php endif; ?>
                        
                        <?php $i = 1; ?>

                        <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($item->checked == 1): ?>
                                <div class="form-group row">    
                                    <label for="companylevel" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Question')); ?> <?php echo e($i++); ?></label>                         
                                    <div class="col-md-6">
                                        <div class="detail_value">
                                            <h3>
                                                <?php echo e($item->name); ?>                                       
                                            </h3>
                                        </div>
                                    </div>
                                </div>
                            <?php else: ?>
                                
                            <?php endif; ?>
                           
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                       
                        <div class="">    
                            <?php $__currentLoopData = $addquesions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="row form-group">
                                    <label for="companylevel" class="col-md-4 col-form-label text-md-right"><?php echo e($item->name); ?></label> 
                                                        
                                    <div class="col-md-6">                                
                                        <?php if($item->option_check == 'on'): ?>    
                                            <select name="companyjob" id="companyjob11" class="form-control">
                                                <?php $__currentLoopData = explode(',', $item->option); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                                    <option><?php echo e($info); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        <?php else: ?>
                                            <input type="text" name="" id="" class="form-control">
                                        <?php endif; ?>                               
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('argon')); ?>/vendor/datatables.net-bs4/css/dataTables.bootstrap4.min.css">
<link rel="stylesheet" href="<?php echo e(asset('argon')); ?>/vendor/datatables.net-buttons-bs4/css/buttons.bootstrap4.min.css">
<link rel="stylesheet" href="<?php echo e(asset('argon')); ?>/vendor/datatables.net-select-bs4/css/select.bootstrap4.min.css">
    
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('argon')); ?>/vendor/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?php echo e(asset('argon')); ?>/vendor/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="<?php echo e(asset('argon')); ?>/vendor/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
<script src="<?php echo e(asset('argon')); ?>/vendor/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js"></script>
<script src="<?php echo e(asset('argon')); ?>/vendor/datatables.net-buttons/js/buttons.html5.min.js"></script>
<script src="<?php echo e(asset('argon')); ?>/vendor/datatables.net-buttons/js/buttons.flash.min.js"></script>
<script src="<?php echo e(asset('argon')); ?>/vendor/datatables.net-buttons/js/buttons.print.min.js"></script>
<script src="<?php echo e(asset('argon')); ?>/vendor/datatables.net-select/js/dataTables.select.min.js"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\WEB\2021-05\10\survey\resources\views/admin/survey/detail.blade.php ENDPATH**/ ?>