

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header"><?php echo e(__('View Survey')); ?></div>

                <div class="card-body">

                    <div class="text-right">
                        <a href="<?php echo e(route('createSurvey')); ?>">
                            <button class="btn btn-primary">Create Survey</button>
                        </a>                       
                    </div>

                    <div class="table-responsive py-4">
                        <table class="table align-items-center table-flush text-center"  id="datatable-basic">
                            <thead class="thead-light">
                                <tr>                                   
                                    <th scope="col"><?php echo e(__(' Name')); ?></th> 
                                    <th scope="col"><?php echo e(__(' Client')); ?></th> 
                                    <th scope="col"><?php echo e(__(' Project')); ?></th> 
                                    <th scope="col"><?php echo e(__(' Description')); ?></th> 
                                    <th scope="col"><?php echo e(__(' Code')); ?></th> 
                                    <th scope="col"><?php echo e(__(' Link')); ?></th>                   
                                    <th scope="col"></th>                                  
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>         
                                        <input type="hidden" name="id" class="id" value="<?php echo e($option->id); ?>" />  
                                        <input type="hidden" name="name" class="name" value="<?php echo e($option->name); ?>" />                                         

                                        <td><?php echo e($option->name); ?></td>

                                        <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($item->id == $option->client_id): ?>
                                                <td><?php echo e($item->name); ?></td>
                                            <?php endif; ?>                                            
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($item->id == $option->project_id): ?>
                                                <td><?php echo e($item->name); ?></td>
                                            <?php endif; ?>                                            
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                        <td><?php echo e($option->description); ?></td>                                       
                                        <td><?php echo e($option->code); ?></td> 
                                        <td><?php echo e($option->surveylink); ?></td>          

                                        
                                        <td class="text-right">
                                            <div class="dropdown">
                                                <a class="btn btn-sm btn-icon-only text-light" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                    <i class="fas fa-ellipsis-v"></i>
                                                </a>
                                                <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">                                                        
                                                    <a href="<?php echo e(route('surveyDetail', $option->id)); ?>" class="dropdown-item" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Detail"><i class="ni ni-bullet-list-67"></i> Detail</a>
                                                    <a href="<?php echo e(route('surveyReport', $option->id)); ?>" class="dropdown-item" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Report"><i class="ni ni-bullet-list-67"></i> Report</a>
                                                    <a href="<?php echo e(route('surveyDelete', $option->id)); ?>" onclick="return window.confirm('Are you sure?')" class="dropdown-item" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Delete"><i class="fa fa-trash"></i> Delete</a>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('argon')); ?>/vendor/datatables.net-bs4/css/dataTables.bootstrap4.min.css">
<link rel="stylesheet" href="<?php echo e(asset('argon')); ?>/vendor/datatables.net-buttons-bs4/css/buttons.bootstrap4.min.css">
<link rel="stylesheet" href="<?php echo e(asset('argon')); ?>/vendor/datatables.net-select-bs4/css/select.bootstrap4.min.css">
    
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('argon')); ?>/vendor/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?php echo e(asset('argon')); ?>/vendor/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="<?php echo e(asset('argon')); ?>/vendor/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
<script src="<?php echo e(asset('argon')); ?>/vendor/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js"></script>
<script src="<?php echo e(asset('argon')); ?>/vendor/datatables.net-buttons/js/buttons.html5.min.js"></script>
<script src="<?php echo e(asset('argon')); ?>/vendor/datatables.net-buttons/js/buttons.flash.min.js"></script>
<script src="<?php echo e(asset('argon')); ?>/vendor/datatables.net-buttons/js/buttons.print.min.js"></script>
<script src="<?php echo e(asset('argon')); ?>/vendor/datatables.net-select/js/dataTables.select.min.js"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\WEB\2021-05\10\survey\resources\views/admin/survey/viewSurvey.blade.php ENDPATH**/ ?>