

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header"><?php echo e(__('View Survey')); ?></div>

                <div class="card-body">

                    <div class="table-responsive py-4">
                        <div class="detail_value">
                            Basic Answers
                        </div>
                        <table class="table align-items-center table-flush text-center"  id="datatable-basic">
                            <thead class="thead-light">
                                <tr>                                   
                                    <th scope="col"><?php echo e(__(' User Name')); ?></th>                                     
                                    <th scope="col"><?php echo e(__(' Company')); ?></th> 
                                    <th scope="col"><?php echo e(__(' City')); ?></th> 
                                    <th scope="col"><?php echo e(__(' Company Area')); ?></th>
                                    <th scope="col"><?php echo e(__(' Company Level')); ?></th>
                                    <th scope="col"><?php echo e(__(' Company Job')); ?></th>  
                                    <th scope="col"><?php echo e(__(' Date')); ?></th>                                    
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $suranswers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>                                               
                                        <td>
                                            <?php if($option->user_name != 'undefined'): ?>
                                                <?php echo e($option->user_name); ?>

                                            <?php else: ?>
                                                
                                            <?php endif; ?>
                                        </td>

                                        <td>
                                            <?php if($option->company != 'undefined'): ?>
                                                <?php echo e($option->company); ?>

                                            <?php else: ?>
                                                
                                            <?php endif; ?>
                                        </td>

                                        <td>
                                            <?php if($option->city != 'undefined'): ?>
                                                <?php echo e($option->city); ?>

                                            <?php else: ?>
                                                
                                            <?php endif; ?>
                                        </td>

                                        <td>
                                            <?php if($option->company_area != 'undefined'): ?>
                                                <?php echo e($option->company_area); ?>

                                            <?php else: ?>
                                                
                                            <?php endif; ?>
                                        </td>

                                        <td>
                                            <?php if($option->company_level != 'undefined'): ?>
                                                <?php echo e($option->company_level); ?>

                                            <?php else: ?>
                                                
                                            <?php endif; ?>
                                        </td>

                                        <td>
                                            <?php if($option->comany_job != 'undefined'): ?>
                                                <?php echo e($option->comany_job); ?>

                                            <?php else: ?>
                                                
                                            <?php endif; ?>
                                        </td>

                                        <td>
                                            <?php if($option->survey_date != 'undefined'): ?>
                                                <?php echo e($option->survey_date); ?>

                                            <?php else: ?>
                                                
                                            <?php endif; ?>
                                        </td>                                                                              
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>                        
                    </div>

                    <div class="table-responsive py-4">
                        <div class="detail_value">
                            Question and Answers
                        </div>
                        <table class="table align-items-center table-flush text-center"  id="datatable-basic1">
                            <thead class="thead-light">
                                <tr>                                   
                                    <th scope="col"><?php echo e(__(' Questions')); ?></th>                                     
                                    <th scope="col"><?php echo e(__(' Casi nunca')); ?></th> 
                                    <th scope="col"><?php echo e(__(' Algunas veces')); ?></th> 
                                    <th scope="col"><?php echo e(__(' Casi siempre')); ?></th>
                                    <th scope="col"><?php echo e(__(' Siempre')); ?></th>                                                                     
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>                                               
                                        <td>
                                           <?php echo e($option->name); ?>

                                        </td>

                                        <td>
                                           <?php echo e($option->queanswers()->where('que_answer', 1)->count()); ?>

                                        </td>
                                        <td>
                                            <?php echo e($option->queanswers()->where('que_answer', 2)->count()); ?>

                                        </td>
                                        <td> 
                                            <?php echo e($option->queanswers()->where('que_answer', 3)->count()); ?>                                           
                                        </td>
                                        <td>
                                            <?php echo e($option->queanswers()->where('que_answer', 4)->count()); ?>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>                        
                    </div>


                    <div class="table-responsive py-4">
                        <div class="detail_value">
                           Additional Question and Answers
                        </div>
                        
                        <table class="table align-items-center table-flush text-center"  id="datatable-basic2">
                            <thead class="thead-light">
                                <tr>    
                                    <?php $__currentLoopData = $addquesions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                               
                                        <th scope="col"><?php echo e($option->name); ?></th>                                     
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                                                
                                </tr>
                            </thead>
                            <tbody> 
                                <?php $__currentLoopData = $suranswers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <tr>
                                        <?php $__currentLoopData = $addquesions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <td>
                                                <?php echo e($option->addanswers()->where('suranswer_id', $option->id)->where('addquestion_id', $item->id)->first()->addanswer); ?>    
                                            </td>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>       
                                   </tr>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  
                               
                            </tbody>
                        </table>                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('argon')); ?>/vendor/datatables.net-bs4/css/dataTables.bootstrap4.min.css">
<link rel="stylesheet" href="<?php echo e(asset('argon')); ?>/vendor/datatables.net-buttons-bs4/css/buttons.bootstrap4.min.css">
<link rel="stylesheet" href="<?php echo e(asset('argon')); ?>/vendor/datatables.net-select-bs4/css/select.bootstrap4.min.css">
    
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('argon')); ?>/vendor/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?php echo e(asset('argon')); ?>/vendor/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="<?php echo e(asset('argon')); ?>/vendor/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
<script src="<?php echo e(asset('argon')); ?>/vendor/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js"></script>
<script src="<?php echo e(asset('argon')); ?>/vendor/datatables.net-buttons/js/buttons.html5.min.js"></script>
<script src="<?php echo e(asset('argon')); ?>/vendor/datatables.net-buttons/js/buttons.flash.min.js"></script>
<script src="<?php echo e(asset('argon')); ?>/vendor/datatables.net-buttons/js/buttons.print.min.js"></script>
<script src="<?php echo e(asset('argon')); ?>/vendor/datatables.net-select/js/dataTables.select.min.js"></script>
<script>
    var DatatableBasic = (function() {

        var $dtBasic1 = $('#datatable-basic1');
        var $dtBasic2 = $('#datatable-basic2');
        // var $dtBasic3 = $('#datatable-basic3');
        // var $dtBasic4 = $('#datatable-basic4');
        // var $dtBasic5 = $('#datatable-basic5');
        // var $dtBasic6 = $('#datatable-basic6');
        // var $dtBasic7 = $('#datatable-basic7');

        function init($this) {

            var options = {
                keys: !0,
                select: {
                    style: "multi"
                },
                language: {
                    paginate: {
                        previous: "<i class='fas fa-angle-left'>",
                        next: "<i class='fas fa-angle-right'>"
                    }
                },
            };

            var table = $this.on( 'init.dt', function () {
                $('div.dataTables_length select').removeClass('custom-select custom-select-sm');

            }).DataTable(options);
        }

        if ($dtBasic1.length) {
            init($dtBasic1);
        }

        if ($dtBasic2.length) {
            init($dtBasic2);
        }

        // if ($dtBasic3.length) {
        //     init($dtBasic3);
        // }

        // if ($dtBasic4.length) {
        //     init($dtBasic4);
        // }

        // if ($dtBasic5.length) {
        //     init($dtBasic5);
        // }

        // if ($dtBasic6.length) {
        //     init($dtBasic6);
        // }

        // if ($dtBasic7.length) {
        //     init($dtBasic7);
        // }

    })();
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\WEB\2021-05\10\survey\resources\views/client/surveyReport.blade.php ENDPATH**/ ?>