<nav class="sidenav navbar navbar-vertical fixed-left navbar-expand-xs navbar-light bg-white" id="sidenav-main">
    <div class="scrollbar-inner scroll-scrollx_visible">
        <div class="sidenav-header d-flex align-items-center">
            <a class="navbar-brand" href="<?php echo e(route('home')); ?>">
                <img src = "<?php echo e(asset('logo.png')); ?>"/>
            </a>
            <div class="ml-auto">
                <div class="sidenav-toggler d-none d-xl-block" data-action="sidenav-unpin" data-target="#sidenav-main">
                    <div class="sidenav-toggler-inner">
                        <i class="sidenav-toggler-line"></i>
                        <i class="sidenav-toggler-line"></i>
                        <i class="sidenav-toggler-line"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="navbar-inner">
            <div class="collapse navbar-collapse" id="sidenav-collapse-main">
                <ul class="navbar-nav">
                    <?php
                         $role = auth()->user()->role;
                    ?>
                    <?php if($role == 1): ?>
                        <li class="nav-item ">
                            <a href="#navbar-basic" class="nav-link" data-toggle="collapse" role="button" aria-expanded="true" aria-controls="navbar-multilevel">
                                <?php echo e(__('Basic Paramenters')); ?>

                            </a>
                            <div class="collapse show" id="navbar-basic" style="">
                                <ul class="nav nav-sm flex-column">

                                    
                                    
                                    <li class="nav-item">
                                        <a class="nav-link collapsed" href="<?php echo e(route('viewCulture')); ?>" role="button"  aria-controls="navbar-dashboards">
                                            <i class="ni ni-book-bookmark text-primary"></i>
                                            <span class="nav-link-text"><?php echo e(__('Cultures')); ?></span>
                                        </a>
                                    </li>
                                
                                    <li class="nav-item">
                                        <a class="nav-link collapsed" href="<?php echo e(route('viewModel')); ?>" role="button"  aria-controls="navbar-dashboards">
                                            <i class="ni ni-book-bookmark text-primary"></i>
                                            <span class="nav-link-text"><?php echo e(__('Models')); ?></span>
                                        </a>
                                    </li>                               
                                    
                                    <li class="nav-item">
                                        <a class="nav-link collapsed" href="<?php echo e(route('viewComponent')); ?>" role="button"  aria-controls="navbar-dashboards">
                                            <i class="ni ni-book-bookmark text-primary"></i>
                                            <span class="nav-link-text"><?php echo e(__('Components')); ?></span>
                                        </a>
                                    </li>
                                
                                    
                                    <li class="nav-item">
                                        <a class="nav-link collapsed" href="<?php echo e(route('viewAttribute')); ?>" role="button"  aria-controls="navbar-dashboards">
                                            <i class="ni ni-book-bookmark text-primary"></i>
                                            <span class="nav-link-text"><?php echo e(__('Attributes')); ?></span>
                                        </a>
                                    </li>
                                    
                                    <li class="nav-item">
                                        <a class="nav-link collapsed" href="<?php echo e(route('viewProject')); ?>" role="button"  aria-controls="navbar-dashboards">
                                            <i class="ni ni-book-bookmark text-primary"></i>
                                            <span class="nav-link-text"><?php echo e(__('Project Types')); ?></span>
                                        </a>
                                    </li>
                                    
                                    <li class="nav-item">
                                        <a class="nav-link collapsed" href="<?php echo e(route('viewEvalution')); ?>" role="button"  aria-controls="navbar-dashboards">
                                            <i class="ni ni-book-bookmark text-primary"></i>
                                            <span class="nav-link-text"><?php echo e(__('Evalutions')); ?></span>
                                        </a>
                                    </li>
                                    
                                    <li class="nav-item">
                                        <a class="nav-link collapsed" href="<?php echo e(route('viewModelanalysis')); ?>" role="button"  aria-controls="navbar-dashboards">
                                            <i class="ni ni-book-bookmark text-primary"></i>
                                            <span class="nav-link-text"><?php echo e(__('Analysis Models')); ?></span>
                                        </a>
                                    </li>                               

                                </ul>
                            </div>                                           
                        </li>

                        <li class="nav-item ">
                            <a href="#navbar-client" class="nav-link" data-toggle="collapse" role="button" aria-expanded="true" aria-controls="navbar-multilevel">
                                <?php echo e(__('Clients')); ?>

                            </a>
                            <div class="collapse" id="navbar-client" style="">
                                <ul class="nav nav-sm flex-column">
                                    <li class="nav-item">
                                        <a class="nav-link collapsed" href="<?php echo e(route('createClient')); ?>" role="button"  aria-controls="navbar-dashboards">
                                            <i class="ni ni-book-bookmark text-primary"></i>
                                            <span class="nav-link-text"><?php echo e(__('Create Client')); ?></span>
                                        </a>  
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link collapsed" href="<?php echo e(route('viewClient')); ?>" role="button"  aria-controls="navbar-dashboards">
                                            <i class="ni ni-book-bookmark text-primary"></i>
                                            <span class="nav-link-text"><?php echo e(__('View Client')); ?></span>
                                        </a>   
                                    </li>
                                    
                                </ul>
                            </div>                                           
                        </li> 
                        
                        <li class="nav-item ">
                            <a href="#navbar-survey" class="nav-link" data-toggle="collapse" role="button" aria-expanded="true" aria-controls="navbar-multilevel">
                                <?php echo e(__('Surveys')); ?>

                            </a>
                            <div class="collapse" id="navbar-survey" style="">
                                <ul class="nav nav-sm flex-column">
                                    <li class="nav-item">
                                        <a class="nav-link collapsed" href="<?php echo e(route('createSurvey')); ?>" role="button"  aria-controls="navbar-dashboards">
                                            <i class="ni ni-book-bookmark text-primary"></i>
                                            <span class="nav-link-text"><?php echo e(__('Create Survey')); ?></span>
                                        </a>  
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link collapsed" href="<?php echo e(route('viewSurvey')); ?>" role="button"  aria-controls="navbar-dashboards">
                                            <i class="ni ni-book-bookmark text-primary"></i>
                                            <span class="nav-link-text"><?php echo e(__('View Survey')); ?></span>
                                        </a>   
                                    </li>
                                    
                                </ul>
                            </div>                                           
                        </li>
                    <?php else: ?>
                    <li class="nav-item ">
                        <a class="nav-link collapsed" href="<?php echo e(route('guest')); ?>" role="button"  aria-controls="navbar-dashboards">
                            <i class="ni ni-book-bookmark text-primary"></i>
                            <span class="nav-link-text"><?php echo e(__('View Survey')); ?></span>
                        </a> 
                    </li>
                    <?php endif; ?>
                     

                    
                </ul>
            </div>
        </div>
    </div>
</nav><?php /**PATH E:\WEB\2021-05\10\survey\resources\views/layouts/navbars/sidebar.blade.php ENDPATH**/ ?>